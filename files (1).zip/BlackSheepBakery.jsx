import React, { useState, useEffect } from 'react';
import { Search, ShoppingCart, Menu, X, LogIn, Clock, MapPin, Phone, Star, Leaf, ChevronRight, Home, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Image URLs from Unsplash & Pexels (Premium Bakery & Food Photography)
const HERO_IMAGE = 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=1200&h=500&fit=crop&q=80';

// Dummy food data with real images
const MENU_DATA = {
  bakery: [
    { id: 1, name: 'Sourdough Loaf', category: 'bakery', price: 450, image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&h=400&fit=crop&q=80', description: 'Artisan sourdough with perfect crust', veg: true, rating: 4.8, reviews: 234 },
    { id: 2, name: 'Croissant', category: 'bakery', price: 120, image: 'https://images.unsplash.com/photo-1585518419759-47c571455e85?w=400&h=400&fit=crop&q=80', description: 'Buttery French croissant', veg: true, rating: 4.7, reviews: 189 },
    { id: 3, name: 'Chocolate Eclairs', category: 'bakery', price: 180, image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&h=400&fit=crop&q=80', description: 'Dark chocolate filled eclairs', veg: true, rating: 4.9, reviews: 156 },
    { id: 4, name: 'Multigrain Bread', category: 'bakery', price: 380, image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop&q=80', description: 'Healthy multigrain with seeds', veg: true, rating: 4.6, reviews: 201 },
  ],
  desserts: [
    { id: 5, name: 'Chocolate Cake', category: 'desserts', price: 680, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=400&fit=crop&q=80', description: 'Rich dark chocolate layer cake', veg: true, rating: 4.9, reviews: 445 },
    { id: 6, name: 'Cheesecake', category: 'desserts', price: 620, image: 'https://images.unsplash.com/photo-1615521441511-da43a5dd8e8e?w=400&h=400&fit=crop&q=80', description: 'Creamy NY style cheesecake', veg: true, rating: 4.8, reviews: 378 },
    { id: 7, name: 'Tiramisu', category: 'desserts', price: 450, image: 'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=400&h=400&fit=crop&q=80', description: 'Classic Italian tiramisu', veg: true, rating: 4.7, reviews: 289 },
    { id: 8, name: 'Brownie Fudge', category: 'desserts', price: 280, image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&h=400&fit=crop&q=80', description: 'Fudgy chocolate brownie', veg: true, rating: 4.8, reviews: 567 },
  ],
  drinks: [
    { id: 9, name: 'Espresso', category: 'drinks', price: 120, image: 'https://images.unsplash.com/photo-1561758033-d89a0ad7b003?w=400&h=400&fit=crop&q=80', description: 'Rich and bold espresso', veg: true, rating: 4.7, reviews: 234 },
    { id: 10, name: 'Cappuccino', category: 'drinks', price: 180, image: 'https://images.unsplash.com/photo-1577968345225-cd6628e6a37f?w=400&h=400&fit=crop&q=80', description: 'Creamy Italian cappuccino', veg: true, rating: 4.8, reviews: 456 },
    { id: 11, name: 'Iced Latte', category: 'drinks', price: 200, image: 'https://images.unsplash.com/photo-1517701550927-30cf4ba53dba?w=400&h=400&fit=crop&q=80', description: 'Chilled latte with cold brew', veg: true, rating: 4.6, reviews: 345 },
    { id: 12, name: 'Hot Chocolate', category: 'drinks', price: 150, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=400&fit=crop&q=80', description: 'Creamy hot chocolate', veg: true, rating: 4.9, reviews: 523 },
  ],
  combos: [
    { id: 13, name: 'Breakfast Combo', category: 'combos', price: 499, image: 'https://images.unsplash.com/photo-1580959375944-abd7e991f971?w=400&h=400&fit=crop&q=80', description: 'Croissant + Coffee + Pastry', veg: true, rating: 4.8, reviews: 289 },
    { id: 14, name: 'Afternoon Tea Set', category: 'combos', price: 899, image: 'https://images.unsplash.com/photo-1597318986175-31b98696acc5?w=400&h=400&fit=crop&q=80', description: 'Cake + Tea + Scones + Jam', veg: true, rating: 4.9, reviews: 198 },
    { id: 15, name: 'Dessert Platter', category: 'combos', price: 1299, image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&h=400&fit=crop&q=80', description: 'Mix of 5 premium desserts', veg: true, rating: 4.7, reviews: 267 },
    { id: 16, name: 'Baker\'s Select', category: 'combos', price: 699, image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=400&h=400&fit=crop&q=80', description: 'Assorted breads and pastries', veg: true, rating: 4.8, reviews: 345 },
  ],
};

// Gallery images
const GALLERY_IMAGES = [
  'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=500&h=500&fit=crop&q=80',
  'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500&h=500&fit=crop&q=80',
  'https://images.unsplash.com/photo-1597318986175-31b98696acc5?w=500&h=500&fit=crop&q=80',
  'https://images.unsplash.com/photo-1585518419759-47c571455e85?w=500&h=500&fit=crop&q=80',
  'https://images.unsplash.com/photo-1577968345225-cd6628e6a37f?w=500&h=500&fit=crop&q=80',
  'https://images.unsplash.com/photo-1557308534-3d82f37a65fe?w=500&h=500&fit=crop&q=80',
];

const ALL_ITEMS = Object.values(MENU_DATA).flat();

// Navbar Component
const Navbar = ({ cart, onCartClick, isLoggedIn, onLoginClick, onLogoutClick }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <motion.nav 
      className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md border-b border-black/5 z-50"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <motion.div 
            className="flex items-center space-x-3 cursor-pointer"
            whileHover={{ scale: 1.05 }}
          >
            <div className="w-10 h-10 rounded-full overflow-hidden bg-black flex items-center justify-center">
              <img 
                src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='white'/%3E%3Cg fill='black'%3E%3Ccircle cx='50' cy='35' r='15'/%3E%3Cpath d='M 35 50 Q 35 65 50 70 Q 65 65 65 50'/%3E%3Ccircle cx='40' cy='55' r='8'/%3E%3Ccircle cx='60' cy='55' r='8'/%3E%3C/g%3E%3C/svg%3E"
                alt="The Black Sheep"
                className="w-8 h-8"
              />
            </div>
            <div>
              <div className="font-serif text-lg font-bold text-black leading-none">The Black Sheep</div>
              <div className="text-xs text-gray-500 font-medium">Bakery</div>
            </div>
          </motion.div>

          {/* Search Bar - Desktop */}
          <div className="hidden md:block flex-1 max-w-xs mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search bakery items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-full border-0 focus:outline-none focus:ring-2 focus:ring-amber-600 text-sm"
              />
            </div>
          </div>

          {/* Right Items */}
          <div className="flex items-center space-x-4">
            {/* Cart */}
            <motion.button 
              onClick={onCartClick}
              className="relative p-2 hover:bg-gray-100 rounded-full transition"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <ShoppingCart className="w-5 h-5 text-black" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                  {cart.reduce((acc, item) => acc + item.quantity, 0)}
                </span>
              )}
            </motion.button>

            {/* Login/Logout */}
            {isLoggedIn ? (
              <motion.button 
                onClick={onLogoutClick}
                className="hidden sm:flex items-center space-x-1 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-full transition"
                whileHover={{ scale: 1.05 }}
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Logout</span>
              </motion.button>
            ) : (
              <motion.button 
                onClick={onLoginClick}
                className="hidden sm:flex items-center space-x-1 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-full transition"
                whileHover={{ scale: 1.05 }}
              >
                <LogIn className="w-4 h-4" />
                <span className="text-sm font-medium">Login</span>
              </motion.button>
            )}

            {/* Mobile Menu */}
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2"
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Search */}
        {isMenuOpen && (
          <motion.div 
            className="md:hidden pb-4"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
          >
            <div className="relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search bakery items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-full border-0 focus:outline-none focus:ring-2 focus:ring-amber-600 text-sm"
              />
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
};

// Hero Section
const HeroSection = ({ onExploreClick }) => {
  return (
    <motion.div 
      className="mt-16 relative h-96 md:h-[500px] overflow-hidden rounded-2xl mx-4 sm:mx-6 lg:mx-8 mt-20"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      {/* Background Image */}
      <img 
        src={HERO_IMAGE}
        alt="Bakery Hero"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30" />
      
      {/* Content */}
      <div className="relative h-full flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <motion.div 
                className="inline-block mb-4 px-4 py-2 bg-amber-500 text-white rounded-full text-sm font-medium"
                whileHover={{ scale: 1.05 }}
              >
                ✨ Freshly Baked Daily
              </motion.div>
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight drop-shadow-lg">
                Artisan Bakery <br/> Excellence
              </h1>
              <p className="text-gray-100 text-lg mb-8 max-w-lg drop-shadow-md">
                Discover our handcrafted bakery items made with premium ingredients and time-honored techniques. Order now for fresh delivery.
              </p>
              <motion.button 
                onClick={onExploreClick}
                className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 rounded-full font-medium flex items-center space-x-2 transition group shadow-lg"
                whileHover={{ scale: 1.05, boxShadow: '0 20px 40px rgba(217, 119, 6, 0.4)' }}
                whileTap={{ scale: 0.98 }}
              >
                <span>Explore Menu</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition" />
              </motion.button>
            </motion.div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// Category Tabs
const CategoryTabs = ({ categories, activeCategory, onCategoryChange }) => {
  return (
    <motion.div 
      className="flex overflow-x-auto space-x-2 pb-4 mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {categories.map((cat) => (
        <motion.button
          key={cat}
          onClick={() => onCategoryChange(cat)}
          className={`px-6 py-2 rounded-full font-medium whitespace-nowrap transition ${
            activeCategory === cat
              ? 'bg-amber-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.98 }}
        >
          {cat.charAt(0).toUpperCase() + cat.slice(1)}
        </motion.button>
      ))}
    </motion.div>
  );
};

// Food Card
const FoodCard = ({ item, onAddToCart, inCart }) => {
  const cartItem = inCart.find(c => c.id === item.id);
  const [imageLoaded, setImageLoaded] = useState(false);

  return (
    <motion.div 
      className="bg-white rounded-2xl overflow-hidden border border-black/5 hover:border-amber-200 transition group"
      whileHover={{ y: -8, boxShadow: '0 20px 40px rgba(0, 0, 0, 0.08)' }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {/* Image Container */}
      <div className="relative h-48 bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center overflow-hidden">
        <motion.img 
          src={item.image}
          alt={item.name}
          className={`w-full h-full object-cover ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          whileHover={{ scale: 1.1 }}
          transition={{ type: 'spring', damping: 20 }}
        />
        
        {!imageLoaded && (
          <div className="absolute inset-0 bg-gradient-to-br from-amber-50 to-orange-50 animate-pulse" />
        )}
        
        {item.veg && (
          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-3 py-1 rounded-full flex items-center space-x-1 text-xs font-medium text-green-700 shadow-md">
            <Leaf className="w-3 h-3" />
            <span>Vegetarian</span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="font-serif text-lg font-bold text-black mb-1">{item.name}</h3>
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{item.description}</p>

        {/* Rating */}
        <div className="flex items-center space-x-1 mb-3">
          <div className="flex items-center text-amber-600">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                className="w-3 h-3" 
                fill={i < Math.floor(item.rating) ? 'currentColor' : 'none'}
              />
            ))}
          </div>
          <span className="text-xs text-gray-600">({item.reviews})</span>
        </div>

        {/* Price & Action */}
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-black">₹{item.price}</div>
          {cartItem ? (
            <div className="flex items-center space-x-2 bg-amber-100 rounded-full px-2 py-1">
              <button 
                onClick={() => onAddToCart(item, -1)}
                className="text-amber-700 hover:text-amber-900 font-bold"
              >
                −
              </button>
              <span className="text-sm font-medium text-amber-900 w-6 text-center">{cartItem.quantity}</span>
              <button 
                onClick={() => onAddToCart(item, 1)}
                className="text-amber-700 hover:text-amber-900 font-bold"
              >
                +
              </button>
            </div>
          ) : (
            <motion.button 
              onClick={() => onAddToCart(item, 1)}
              className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-full text-sm font-medium transition"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Add
            </motion.button>
          )}
        </div>
      </div>
    </motion.div>
  );
};

// Cart Drawer
const CartDrawer = ({ isOpen, onClose, cart, onUpdateCart, onCheckout }) => {
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = total > 0 ? 50 : 0;
  const tax = total > 0 ? Math.round(total * 0.05) : 0;
  const finalTotal = total + deliveryFee + tax;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div 
            className="fixed right-0 top-0 bottom-0 w-full sm:w-96 bg-white shadow-2xl z-40 flex flex-col"
            initial={{ x: 400 }}
            animate={{ x: 0 }}
            exit={{ x: 400 }}
            transition={{ type: 'spring', damping: 20 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-black/5">
              <h2 className="font-serif text-2xl font-bold">Your Cart</h2>
              <motion.button 
                onClick={onClose}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <X className="w-6 h-6" />
              </motion.button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-400">
                  <ShoppingCart className="w-12 h-12 mb-2 opacity-50" />
                  <p>Your cart is empty</p>
                </div>
              ) : (
                cart.map((item) => (
                  <motion.div 
                    key={item.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg group"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                  >
                    <div className="flex-1">
                      <div className="font-medium text-black">{item.name}</div>
                      <div className="text-sm text-gray-600">₹{item.price} × {item.quantity}</div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => onUpdateCart(item.id, -1)}
                        className="w-6 h-6 flex items-center justify-center bg-white border border-gray-200 rounded hover:bg-gray-100"
                      >
                        −
                      </button>
                      <span className="w-6 text-center font-medium">{item.quantity}</span>
                      <button 
                        onClick={() => onUpdateCart(item.id, 1)}
                        className="w-6 h-6 flex items-center justify-center bg-white border border-gray-200 rounded hover:bg-gray-100"
                      >
                        +
                      </button>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {/* Footer */}
            {cart.length > 0 && (
              <motion.div 
                className="border-t border-black/5 p-6 space-y-3"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">₹{total}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Delivery Fee</span>
                  <span className="font-medium">₹{deliveryFee}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Tax</span>
                  <span className="font-medium">₹{tax}</span>
                </div>
                <div className="border-t border-gray-200 pt-3 flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>₹{finalTotal}</span>
                </div>
                <motion.button 
                  onClick={onCheckout}
                  className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg font-medium transition mt-4"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Proceed to Checkout
                </motion.button>
              </motion.div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

// Gallery Section
const GallerySection = () => {
  const [selectedImage, setSelectedImage] = useState(null);

  return (
    <motion.section 
      className="py-20 bg-white"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
        >
          <h2 className="font-serif text-4xl font-bold text-black mb-3">Our Creations</h2>
          <p className="text-gray-600">A glimpse into our artisan bakery collection</p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {GALLERY_IMAGES.map((image, i) => (
            <motion.div 
              key={i}
              className="relative h-64 rounded-2xl overflow-hidden cursor-pointer group"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => setSelectedImage(image)}
            >
              <img 
                src={image}
                alt={`Gallery ${i + 1}`}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-center justify-center">
                <motion.div 
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileHover={{ opacity: 1, scale: 1 }}
                  className="bg-white/90 rounded-full p-3"
                >
                  <ChevronRight className="w-6 h-6 text-black rotate-90" />
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Image Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div 
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedImage(null)}
          >
            <motion.img 
              src={selectedImage}
              alt="Gallery"
              className="max-w-4xl max-h-96 rounded-2xl"
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.section>
  );
};

// Restaurant Info Section
const RestaurantInfo = () => {
  return (
    <motion.section 
      className="bg-black text-white py-16"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          {[
            { icon: Clock, label: 'Opening Hours', value: '7:00 AM - 10:00 PM' },
            { icon: MapPin, label: 'Location', value: 'Jamshedpur, Jharkhand' },
            { icon: Phone, label: 'Contact', value: '+91 98765 43210' },
            { icon: ShoppingCart, label: 'Min Order', value: '₹200' },
          ].map((info, i) => (
            <motion.div 
              key={i}
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <info.icon className="w-8 h-8 mx-auto mb-3 text-amber-500" />
              <div className="text-sm text-gray-400 mb-2">{info.label}</div>
              <div className="font-medium">{info.value}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.section>
  );
};

// Testimonials Section
const TestimonialSection = () => {
  const testimonials = [
    { name: 'Sarah Khan', text: 'The croissants are absolutely divine! Fresh and buttery every time.', rating: 5, image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop&q=80' },
    { name: 'Ravi Patel', text: 'Best sourdough bread in the city. Highly recommended for quality.', rating: 5, image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&q=80' },
    { name: 'Priya Sharma', text: 'The chocolate cake is a masterpiece. Perfect for celebrations!', rating: 5, image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&q=80' },
  ];

  return (
    <motion.section 
      className="py-20 relative overflow-hidden"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1557308534-3d82f37a65fe?w=1200&h=600&fit=crop&q=80"
          alt="Bakery background"
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/60 to-black/50" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
        >
          <h2 className="font-serif text-4xl font-bold text-white mb-3">What Our Customers Say</h2>
          <p className="text-gray-200">Trusted by hundreds of satisfied customers</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, i) => (
            <motion.div 
              key={i}
              className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 hover:border-white/40 transition"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -8 }}
            >
              <div className="flex items-center space-x-1 mb-3">
                {[...Array(testimonial.rating)].map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-white/90 mb-4">"{testimonial.text}"</p>
              <div className="flex items-center space-x-3">
                <img 
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-10 h-10 rounded-full object-cover"
                  loading="lazy"
                />
                <div className="font-medium text-white">{testimonial.name}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.section>
  );
};

// Footer
const Footer = () => {
  return (
    <footer className="bg-black text-white py-12 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="text-2xl">🐑</div>
              <div className="font-serif font-bold">The Black Sheep</div>
            </div>
            <p className="text-gray-400 text-sm">Premium artisan bakery & cafe</p>
          </div>
          <div>
            <div className="font-bold mb-4">Quick Links</div>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-white transition">Home</a></li>
              <li><a href="#" className="hover:text-white transition">Menu</a></li>
              <li><a href="#" className="hover:text-white transition">Contact</a></li>
              <li><a href="#" className="hover:text-white transition">About</a></li>
            </ul>
          </div>
          <div>
            <div className="font-bold mb-4">Social</div>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#" className="hover:text-white transition">Instagram</a></li>
              <li><a href="#" className="hover:text-white transition">Facebook</a></li>
              <li><a href="#" className="hover:text-white transition">Twitter</a></li>
            </ul>
          </div>
          <div>
            <div className="font-bold mb-4">Contact</div>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>📍 Jamshedpur, Jharkhand</li>
              <li>📞 +91 98765 43210</li>
              <li>✉️ hello@blacksheepbakery.in</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2024 The Black Sheep Bakery. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

// Checkout Page
const CheckoutPage = ({ onBack, cartTotal, cartItems }) => {
  const [step, setStep] = useState(1);

  return (
    <motion.div 
      className="fixed inset-0 bg-white z-50 overflow-y-auto"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="max-w-2xl mx-auto px-4 py-8">
        <motion.button 
          onClick={onBack}
          className="flex items-center space-x-2 text-black mb-8 hover:text-gray-600"
          whileHover={{ x: -4 }}
        >
          <ChevronRight className="w-5 h-5 rotate-180" />
          <span>Back to Cart</span>
        </motion.button>

        <h1 className="font-serif text-3xl font-bold mb-8">Checkout</h1>

        {/* Steps */}
        <div className="flex space-x-4 mb-8">
          {[1, 2, 3].map((s) => (
            <div 
              key={s}
              className={`flex-1 h-2 rounded-full transition ${s <= step ? 'bg-amber-600' : 'bg-gray-200'}`}
            />
          ))}
        </div>

        {step === 1 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-xl font-bold mb-6">Delivery Address</h2>
            <div className="space-y-4">
              <input type="text" placeholder="Full Name" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600" />
              <input type="text" placeholder="Phone Number" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600" />
              <input type="text" placeholder="Full Address" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600" />
              <input type="text" placeholder="City" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600" />
              <motion.button 
                onClick={() => setStep(2)}
                className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg font-medium mt-6"
                whileHover={{ scale: 1.02 }}
              >
                Continue to Payment
              </motion.button>
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-xl font-bold mb-6">Payment Method</h2>
            <div className="space-y-3 mb-6">
              {['Credit/Debit Card', 'Digital Wallet', 'Cash on Delivery'].map((method) => (
                <label key={method} className="flex items-center p-4 border border-gray-300 rounded-lg cursor-pointer hover:border-amber-600 transition">
                  <input type="radio" name="payment" defaultChecked={method === 'Cash on Delivery'} className="mr-3 w-4 h-4" />
                  <span className="font-medium">{method}</span>
                </label>
              ))}
            </div>
            <motion.button 
              onClick={() => setStep(3)}
              className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg font-medium"
              whileHover={{ scale: 1.02 }}
            >
              Review Order
            </motion.button>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-xl font-bold mb-6">Order Summary</h2>
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <div className="space-y-3 mb-4 max-h-40 overflow-y-auto">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex justify-between">
                    <div>
                      <div className="font-medium">{item.name}</div>
                      <div className="text-sm text-gray-600">Qty: {item.quantity}</div>
                    </div>
                    <div className="font-medium">₹{item.price * item.quantity}</div>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-300 pt-4 space-y-2">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal</span>
                  <span>₹{cartTotal}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Delivery</span>
                  <span>₹50</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Tax</span>
                  <span>₹{Math.round(cartTotal * 0.05)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg border-t border-gray-300 pt-2">
                  <span>Total</span>
                  <span>₹{cartTotal + 50 + Math.round(cartTotal * 0.05)}</span>
                </div>
              </div>
            </div>
            <motion.button 
              onClick={onBack}
              className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-lg font-medium"
              whileHover={{ scale: 1.02 }}
            >
              Place Order - ₹{cartTotal + 50 + Math.round(cartTotal * 0.05)}
            </motion.button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

// Main App Component
export default function BlackSheepBakery() {
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState('bakery');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isCheckout, setIsCheckout] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);

  const categories = ['bakery', 'desserts', 'drinks', 'combos'];
  const filteredItems = MENU_DATA[activeCategory] || [];

  const handleAddToCart = (item, quantity) => {
    setCart((prevCart) => {
      const existing = prevCart.find((c) => c.id === item.id);
      if (existing) {
        const updated = { ...existing, quantity: existing.quantity + quantity };
        return updated.quantity <= 0 
          ? prevCart.filter((c) => c.id !== item.id)
          : prevCart.map((c) => c.id === item.id ? updated : c);
      }
      return quantity > 0 ? [...prevCart, { ...item, quantity }] : prevCart;
    });
  };

  const handleUpdateCart = (id, quantity) => {
    handleAddToCart(ALL_ITEMS.find((i) => i.id === id), quantity);
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="bg-white min-h-screen">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Poppins:wght@400;500;600;700&display=swap');
        
        * {
          font-family: 'Poppins', sans-serif;
        }

        .font-serif {
          font-family: 'Playfair Display', serif;
        }

        ::-webkit-scrollbar {
          width: 8px;
        }

        ::-webkit-scrollbar-track {
          background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
          background: #d97706;
          border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: #b45309;
        }
      `}</style>

      <Navbar 
        cart={cart} 
        onCartClick={() => setIsCartOpen(true)}
        isLoggedIn={isLoggedIn}
        onLoginClick={() => setIsLoggedIn(true)}
        onLogoutClick={() => setIsLoggedIn(false)}
      />

      {isCheckout ? (
        <CheckoutPage 
          onBack={() => setIsCheckout(false)}
          cartTotal={cartTotal}
          cartItems={cart}
        />
      ) : (
        <>
          <HeroSection onExploreClick={() => {
            const menu = document.getElementById('menu');
            menu?.scrollIntoView({ behavior: 'smooth' });
          }} />

          <section id="menu" className="py-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div 
                className="mb-12"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
              >
                <h2 className="font-serif text-4xl font-bold text-black mb-2">Our Menu</h2>
                <p className="text-gray-600">Handcrafted bakery items for every moment</p>
              </motion.div>

              <CategoryTabs 
                categories={categories}
                activeCategory={activeCategory}
                onCategoryChange={setActiveCategory}
              />

              <motion.div 
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ staggerChildren: 0.1 }}
              >
                {filteredItems.map((item) => (
                  <FoodCard 
                    key={item.id}
                    item={item}
                    onAddToCart={handleAddToCart}
                    inCart={cart}
                  />
                ))}
              </motion.div>
            </div>
          </section>

          <GallerySection />

          <RestaurantInfo />
          <TestimonialSection />
          <Footer />
        </>
      )}

      <CartDrawer 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateCart={handleUpdateCart}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckout(true);
        }}
      />
    </div>
  );
}
