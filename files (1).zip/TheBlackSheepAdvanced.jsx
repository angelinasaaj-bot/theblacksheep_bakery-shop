import React, { useState, useEffect, useRef } from 'react';
import { Search, ShoppingCart, Menu, X, MapPin, Phone, Clock, Star, Leaf, ChevronRight, Home, LogOut, LogIn, Sun, Moon, Heart, Share2, Truck, UtensilsCrossed, ChevronDown, Plus, Minus, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Premium Food Data
const FOOD_ITEMS = [
  // Pizza Category
  { id: 1, category: 'pizza', name: 'Margherita Pizza', price: 350, image: 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?w=400&h=400&fit=crop&q=80', description: 'Fresh mozzarella, basil, tomato sauce', veg: true, rating: 4.8, reviews: 234, time: '25-30 min', bestseller: true, calories: '280 cal' },
  { id: 2, category: 'pizza', name: 'Pepperoni Pizza', price: 450, image: 'https://images.unsplash.com/photo-1628840042765-356cda07f4ee?w=400&h=400&fit=crop&q=80', description: 'Loaded with pepperoni and mozzarella', veg: false, rating: 4.7, reviews: 189, time: '25-30 min', bestseller: false, calories: '340 cal' },
  { id: 3, category: 'pizza', name: 'Veggie Supreme', price: 380, image: 'https://images.unsplash.com/photo-1551632440-0b51b28c4b77?w=400&h=400&fit=crop&q=80', description: 'Mixed vegetables with herb sauce', veg: true, rating: 4.6, reviews: 156, time: '25-30 min', bestseller: false, calories: '250 cal' },
  { id: 4, category: 'pizza', name: 'Spicy Chicken Pizza', price: 480, image: 'https://images.unsplash.com/photo-1593504512454-e0f06a7e95dd?w=400&h=400&fit=crop&q=80', description: 'Grilled chicken with spicy sauce', veg: false, rating: 4.9, reviews: 312, time: '25-30 min', bestseller: true, calories: '300 cal' },

  // Burgers Category
  { id: 5, category: 'burgers', name: 'Classic Cheeseburger', price: 280, image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=400&fit=crop&q=80', description: 'Beef patty, cheese, lettuce, tomato', veg: false, rating: 4.7, reviews: 245, time: '15-20 min', bestseller: true, calories: '320 cal' },
  { id: 6, category: 'burgers', name: 'Veggie Burger', price: 240, image: 'https://images.unsplash.com/photo-1585517281735-29a08aa78d27?w=400&h=400&fit=crop&q=80', description: 'Plant-based patty with fresh toppings', veg: true, rating: 4.6, reviews: 178, time: '15-20 min', bestseller: false, calories: '280 cal' },
  { id: 7, category: 'burgers', name: 'Bacon Burger', price: 320, image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?w=400&h=400&fit=crop&q=80', description: 'Crispy bacon with grilled beef', veg: false, rating: 4.8, reviews: 267, time: '15-20 min', bestseller: false, calories: '380 cal' },
  { id: 8, category: 'burgers', name: 'Mushroom Swiss Burger', price: 300, image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=400&h=400&fit=crop&q=80', description: 'Swiss cheese with sautéed mushrooms', veg: true, rating: 4.7, reviews: 201, time: '15-20 min', bestseller: false, calories: '310 cal' },

  // Bakery Category
  { id: 9, category: 'bakery', name: 'Sourdough Loaf', price: 450, image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&h=400&fit=crop&q=80', description: 'Artisan sourdough with perfect crust', veg: true, rating: 4.9, reviews: 334, time: '10-15 min', bestseller: true, calories: '200 cal' },
  { id: 10, category: 'bakery', name: 'Croissant', price: 120, image: 'https://images.unsplash.com/photo-1585518419759-47c571455e85?w=400&h=400&fit=crop&q=80', description: 'Buttery French croissant', veg: true, rating: 4.8, reviews: 289, time: '5-10 min', bestseller: false, calories: '160 cal' },
  { id: 11, category: 'bakery', name: 'Multigrain Bread', price: 380, image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop&q=80', description: 'Healthy multigrain with seeds', veg: true, rating: 4.7, reviews: 201, time: '10-15 min', bestseller: false, calories: '180 cal' },
  { id: 12, category: 'bakery', name: 'Brioche Bun', price: 100, image: 'https://images.unsplash.com/photo-1586190936905-91155e31cdce?w=400&h=400&fit=crop&q=80', description: 'Soft brioche with butter', veg: true, rating: 4.6, reviews: 156, time: '5-10 min', bestseller: false, calories: '140 cal' },

  // Desserts Category
  { id: 13, category: 'desserts', name: 'Chocolate Cake', price: 680, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=400&fit=crop&q=80', description: 'Rich dark chocolate layer cake', veg: true, rating: 4.9, reviews: 445, time: '10-15 min', bestseller: true, calories: '350 cal' },
  { id: 14, category: 'desserts', name: 'Cheesecake', price: 620, image: 'https://images.unsplash.com/photo-1615521441511-da43a5dd8e8e?w=400&h=400&fit=crop&q=80', description: 'Creamy NY style cheesecake', veg: true, rating: 4.8, reviews: 378, time: '10-15 min', bestseller: false, calories: '380 cal' },
  { id: 15, category: 'desserts', name: 'Tiramisu', price: 450, image: 'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=400&h=400&fit=crop&q=80', description: 'Classic Italian tiramisu', veg: true, rating: 4.7, reviews: 289, time: '10-15 min', bestseller: false, calories: '320 cal' },
  { id: 16, category: 'desserts', name: 'Brownie Fudge', price: 280, image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&h=400&fit=crop&q=80', description: 'Fudgy chocolate brownie', veg: true, rating: 4.8, reviews: 567, time: '10-15 min', bestseller: false, calories: '280 cal' },

  // Beverages Category
  { id: 17, category: 'beverages', name: 'Espresso', price: 120, image: 'https://images.unsplash.com/photo-1561758033-d89a0ad7b003?w=400&h=400&fit=crop&q=80', description: 'Rich and bold espresso', veg: true, rating: 4.7, reviews: 234, time: '3-5 min', bestseller: false, calories: '2 cal' },
  { id: 18, category: 'beverages', name: 'Cappuccino', price: 180, image: 'https://images.unsplash.com/photo-1577968345225-cd6628e6a37f?w=400&h=400&fit=crop&q=80', description: 'Creamy Italian cappuccino', veg: true, rating: 4.8, reviews: 456, time: '5-7 min', bestseller: true, calories: '90 cal' },
  { id: 19, category: 'beverages', name: 'Iced Latte', price: 200, image: 'https://images.unsplash.com/photo-1517701550927-30cf4ba53dba?w=400&h=400&fit=crop&q=80', description: 'Chilled latte with cold brew', veg: true, rating: 4.6, reviews: 345, time: '5-7 min', bestseller: false, calories: '120 cal' },
  { id: 20, category: 'beverages', name: 'Hot Chocolate', price: 150, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=400&fit=crop&q=80', description: 'Creamy hot chocolate', veg: true, rating: 4.9, reviews: 523, time: '5-7 min', bestseller: false, calories: '180 cal' },
];

const CATEGORIES = ['pizza', 'burgers', 'bakery', 'desserts', 'beverages'];

// ============ NAVBAR COMPONENT ============
const Navbar = ({ cart, onCartClick, isLoggedIn, onLoginClick, darkMode, toggleDarkMode, activeOrder, onOrderClick }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [deliveryType, setDeliveryType] = useState('delivery');

  return (
    <motion.nav 
      className={`fixed top-0 left-0 right-0 ${darkMode ? 'bg-gray-900/95' : 'bg-white/95'} backdrop-blur-md border-b ${darkMode ? 'border-gray-700' : 'border-gray-200'} z-50 shadow-sm`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Name */}
          <motion.div 
            className="flex items-center space-x-3 cursor-pointer"
            whileHover={{ scale: 1.05 }}
          >
            <div className={`w-10 h-10 rounded-lg ${darkMode ? 'bg-amber-600' : 'bg-gradient-to-br from-amber-500 to-orange-600'} flex items-center justify-center shadow-lg`}>
              <span className="text-white font-bold text-lg">🐑</span>
            </div>
            <div className="hidden sm:block">
              <div className={`font-serif text-lg font-bold ${darkMode ? 'text-white' : 'text-black'}`}>
                The Black Sheep
              </div>
              <div className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>Premium Bakery</div>
            </div>
          </motion.div>

          {/* Delivery/Takeaway Toggle */}
          <div className="hidden md:flex items-center space-x-2 bg-gray-100 dark:bg-gray-800 p-1 rounded-full">
            <motion.button
              onClick={() => setDeliveryType('delivery')}
              className={`px-4 py-2 rounded-full transition ${
                deliveryType === 'delivery'
                  ? 'bg-white dark:bg-gray-700 shadow-md'
                  : 'transparent'
              }`}
              whileHover={{ scale: 1.05 }}
            >
              <div className="flex items-center space-x-1">
                <Truck className="w-4 h-4" />
                <span className="text-sm font-medium">Delivery</span>
              </div>
            </motion.button>
            <motion.button
              onClick={() => setDeliveryType('takeaway')}
              className={`px-4 py-2 rounded-full transition ${
                deliveryType === 'takeaway'
                  ? 'bg-white dark:bg-gray-700 shadow-md'
                  : 'transparent'
              }`}
              whileHover={{ scale: 1.05 }}
            >
              <div className="flex items-center space-x-1">
                <UtensilsCrossed className="w-4 h-4" />
                <span className="text-sm font-medium">Takeaway</span>
              </div>
            </motion.button>
          </div>

          {/* Right Items */}
          <div className="flex items-center space-x-4">
            {/* Search */}
            {isSearchOpen ? (
              <motion.div
                className={`absolute left-4 right-4 sm:relative sm:left-0 sm:right-0 top-16 sm:top-0 ${darkMode ? 'bg-gray-800' : 'bg-gray-100'} rounded-lg`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <input
                  type="text"
                  placeholder="Search items..."
                  className={`w-full px-4 py-2 bg-transparent border-0 focus:outline-none ${darkMode ? 'text-white placeholder-gray-500' : 'placeholder-gray-600'}`}
                />
              </motion.div>
            ) : (
              <motion.button
                onClick={() => setIsSearchOpen(true)}
                className={`p-2 hover:${darkMode ? 'bg-gray-800' : 'bg-gray-100'} rounded-lg transition`}
                whileHover={{ scale: 1.1 }}
              >
                <Search className={`w-5 h-5 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`} />
              </motion.button>
            )}

            {/* Dark Mode */}
            <motion.button
              onClick={toggleDarkMode}
              className={`p-2 hover:${darkMode ? 'bg-gray-800' : 'bg-gray-100'} rounded-lg transition`}
              whileHover={{ scale: 1.1 }}
            >
              {darkMode ? (
                <Sun className="w-5 h-5 text-yellow-400" />
              ) : (
                <Moon className="w-5 h-5 text-gray-700" />
              )}
            </motion.button>

            {/* Cart */}
            <motion.button
              onClick={onCartClick}
              className={`relative p-2 hover:${darkMode ? 'bg-gray-800' : 'bg-gray-100'} rounded-lg transition`}
              whileHover={{ scale: 1.1 }}
            >
              <ShoppingCart className={`w-5 h-5 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`} />
              {cart.length > 0 && (
                <motion.span
                  className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                >
                  {cart.reduce((acc, item) => acc + item.quantity, 0)}
                </motion.span>
              )}
            </motion.button>

            {/* Profile */}
            {isLoggedIn ? (
              <motion.button
                className={`hidden sm:block p-2 hover:${darkMode ? 'bg-gray-800' : 'bg-gray-100'} rounded-lg transition`}
                whileHover={{ scale: 1.1 }}
              >
                <div className="w-6 h-6 bg-gradient-to-br from-amber-400 to-orange-600 rounded-full" />
              </motion.button>
            ) : (
              <motion.button
                onClick={onLoginClick}
                className="hidden sm:flex items-center space-x-1 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg transition"
                whileHover={{ scale: 1.05 }}
              >
                <LogIn className="w-4 h-4" />
                <span className="text-sm font-medium">Login</span>
              </motion.button>
            )}

            {/* Mobile Menu */}
            <motion.button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2"
              whileHover={{ scale: 1.1 }}
            >
              {isMenuOpen ? (
                <X className={`w-5 h-5 ${darkMode ? 'text-white' : 'text-black'}`} />
              ) : (
                <Menu className={`w-5 h-5 ${darkMode ? 'text-white' : 'text-black'}`} />
              )}
            </motion.button>
          </div>
        </div>
      </div>
    </motion.nav>
  );
};

// ============ HERO SECTION ============
const HeroSection = ({ darkMode, onExploreClick }) => {
  return (
    <motion.div
      className={`mt-16 relative h-96 md:h-[500px] overflow-hidden rounded-b-3xl`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      <img
        src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=1200&h=500&fit=crop&q=80"
        alt="Hero"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-transparent" />

      <div className="relative h-full flex items-center px-4 sm:px-8 lg:px-16">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <motion.div
            className="inline-block mb-4 px-4 py-2 bg-amber-500 text-white rounded-full text-sm font-medium backdrop-blur-md"
            whileHover={{ scale: 1.05 }}
          >
            ✨ Fresh & Premium Quality
          </motion.div>
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight drop-shadow-lg">
            Artisan Bakery <br /> Experience
          </h1>
          <p className="text-gray-100 text-lg mb-8 max-w-lg drop-shadow-md">
            Handcrafted with premium ingredients. Order now for fresh delivery.
          </p>
          <motion.button
            onClick={onExploreClick}
            className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 rounded-full font-medium flex items-center space-x-2 transition shadow-lg"
            whileHover={{ scale: 1.05, boxShadow: '0 20px 40px rgba(217, 119, 6, 0.5)' }}
            whileTap={{ scale: 0.98 }}
          >
            <span>Explore Menu</span>
            <ChevronRight className="w-4 h-4" />
          </motion.button>
        </motion.div>
      </div>
    </motion.div>
  );
};

// ============ CATEGORY MENU ============
const CategoryMenu = ({ categories, activeCategory, onCategoryChange, darkMode }) => {
  const scrollContainerRef = useRef(null);

  return (
    <div className={`sticky top-16 ${darkMode ? 'bg-gray-900' : 'bg-white'} border-b ${darkMode ? 'border-gray-800' : 'border-gray-200'} py-4 z-40`}>
      <div className="max-w-7xl mx-auto px-4">
        <motion.div
          ref={scrollContainerRef}
          className="flex overflow-x-auto space-x-2 pb-2 -mb-2 scroll-smooth"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          {categories.map((cat) => (
            <motion.button
              key={cat}
              onClick={() => onCategoryChange(cat)}
              className={`px-6 py-2 rounded-full font-medium whitespace-nowrap transition ${
                activeCategory === cat
                  ? `bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg`
                  : `${darkMode ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </motion.button>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

// ============ FOOD CARD ============
const FoodCard = ({ item, onAddToCart, inCart, darkMode, onCustomize }) => {
  const [showOptions, setShowOptions] = useState(false);
  const cartItem = inCart.find(c => c.id === item.id);

  return (
    <motion.div
      className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl overflow-hidden border ${darkMode ? 'border-gray-700' : 'border-gray-200'} hover:${darkMode ? 'border-amber-500' : 'border-amber-300'} transition group`}
      whileHover={{ y: -8, boxShadow: darkMode ? '0 20px 40px rgba(217, 119, 6, 0.2)' : '0 20px 40px rgba(0, 0, 0, 0.1)' }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {/* Image */}
      <div className="relative h-48 overflow-hidden bg-gradient-to-br from-amber-50 to-orange-50">
        {item.bestseller && (
          <div className="absolute top-3 left-3 bg-red-500 text-white px-3 py-1 rounded-full text-xs font-bold z-10">
            Bestseller
          </div>
        )}
        <motion.img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          loading="lazy"
          whileHover={{ scale: 1.1 }}
        />
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className={`font-serif text-lg font-bold ${darkMode ? 'text-white' : 'text-black'}`}>
            {item.name}
          </h3>
          {item.veg ? (
            <div className="flex items-center justify-center w-6 h-6 border-2 border-green-500 rounded text-green-500 text-xs font-bold">
              V
            </div>
          ) : (
            <div className="flex items-center justify-center w-6 h-6 border-2 border-red-500 rounded text-red-500 text-xs font-bold">
              N
            </div>
          )}
        </div>

        <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-3 line-clamp-2`}>
          {item.description}
        </p>

        {/* Rating & Time */}
        <div className="flex items-center justify-between mb-4 text-xs">
          <div className="flex items-center space-x-1">
            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
            <span className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
              {item.rating} ({item.reviews})
            </span>
          </div>
          <span className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
            ⏱️ {item.time}
          </span>
        </div>

        {/* Price & Button */}
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">
            ₹{item.price}
          </div>
          {cartItem ? (
            <div className={`flex items-center space-x-2 ${darkMode ? 'bg-gray-700' : 'bg-amber-100'} rounded-full px-2 py-1`}>
              <motion.button
                onClick={() => onAddToCart(item, -1)}
                className={`text-amber-700 hover:text-amber-900 font-bold w-6 h-6 flex items-center justify-center`}
                whileTap={{ scale: 0.8 }}
              >
                −
              </motion.button>
              <span className={`text-sm font-medium w-6 text-center ${darkMode ? 'text-white' : 'text-amber-900'}`}>
                {cartItem.quantity}
              </span>
              <motion.button
                onClick={() => onAddToCart(item, 1)}
                className={`text-amber-700 hover:text-amber-900 font-bold w-6 h-6 flex items-center justify-center`}
                whileTap={{ scale: 0.8 }}
              >
                +
              </motion.button>
            </div>
          ) : (
            <motion.button
              onClick={() => {
                setShowOptions(true);
                onCustomize(item);
              }}
              className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white px-4 py-2 rounded-full text-sm font-medium transition"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Add
            </motion.button>
          )}
        </div>
      </div>
    </motion.div>
  );
};

// ============ CART DRAWER ============
const CartDrawer = ({ isOpen, onClose, cart, onUpdateCart, onCheckout, darkMode }) => {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = subtotal > 500 ? 0 : 100;
  const gst = Math.round(subtotal * 0.05);
  const total = subtotal + deliveryFee + gst;

  const [coupon, setCoupon] = useState('');
  const [discount, setDiscount] = useState(0);

  const applyCoupon = () => {
    if (coupon.toUpperCase() === 'FIRST50') {
      setDiscount(Math.round(subtotal * 0.5));
      setCoupon('');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Cart Drawer */}
          <motion.div
            className={`fixed right-0 top-0 bottom-0 w-full sm:w-96 ${darkMode ? 'bg-gray-900' : 'bg-white'} shadow-2xl z-40 flex flex-col`}
            initial={{ x: 400 }}
            animate={{ x: 0 }}
            exit={{ x: 400 }}
            transition={{ type: 'spring', damping: 20 }}
          >
            {/* Header */}
            <div className={`flex items-center justify-between p-6 border-b ${darkMode ? 'border-gray-800' : 'border-gray-200'}`}>
              <h2 className={`font-serif text-2xl font-bold ${darkMode ? 'text-white' : 'text-black'}`}>
                Your Cart
              </h2>
              <motion.button
                onClick={onClose}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <X className={`w-6 h-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`} />
              </motion.button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-400">
                  <ShoppingCart className="w-12 h-12 mb-2 opacity-30" />
                  <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>Your cart is empty</p>
                </div>
              ) : (
                cart.map((item) => (
                  <motion.div
                    key={item.id}
                    className={`flex items-center justify-between p-3 ${darkMode ? 'bg-gray-800' : 'bg-gray-50'} rounded-lg`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                  >
                    <div className="flex-1">
                      <div className={`font-medium ${darkMode ? 'text-white' : 'text-black'}`}>
                        {item.name}
                      </div>
                      <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        ₹{item.price} × {item.quantity}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <motion.button
                        onClick={() => onUpdateCart(item.id, -1)}
                        className={`w-6 h-6 flex items-center justify-center ${darkMode ? 'bg-gray-700' : 'bg-white'} border ${darkMode ? 'border-gray-600' : 'border-gray-200'} rounded hover:${darkMode ? 'bg-gray-600' : 'bg-gray-100'}`}
                        whileTap={{ scale: 0.8 }}
                      >
                        −
                      </motion.button>
                      <span className={`w-6 text-center font-medium ${darkMode ? 'text-white' : 'text-black'}`}>
                        {item.quantity}
                      </span>
                      <motion.button
                        onClick={() => onUpdateCart(item.id, 1)}
                        className={`w-6 h-6 flex items-center justify-center ${darkMode ? 'bg-gray-700' : 'bg-white'} border ${darkMode ? 'border-gray-600' : 'border-gray-200'} rounded hover:${darkMode ? 'bg-gray-600' : 'bg-gray-100'}`}
                        whileTap={{ scale: 0.8 }}
                      >
                        +
                      </motion.button>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {/* Coupon & Summary */}
            {cart.length > 0 && (
              <motion.div
                className={`border-t ${darkMode ? 'border-gray-800' : 'border-gray-200'} p-6 space-y-4`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                {/* Coupon */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Coupon code"
                    value={coupon}
                    onChange={(e) => setCoupon(e.target.value)}
                    className={`flex-1 px-3 py-2 rounded-lg border ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200'} focus:outline-none focus:ring-2 focus:ring-amber-500`}
                  />
                  <motion.button
                    onClick={applyCoupon}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium"
                    whileTap={{ scale: 0.95 }}
                  >
                    Apply
                  </motion.button>
                </div>

                {/* Summary */}
                <div className="space-y-2">
                  <div className={`flex justify-between text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    <span>Subtotal</span>
                    <span>₹{subtotal}</span>
                  </div>
                  {deliveryFee > 0 && (
                    <div className={`flex justify-between text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      <span>Delivery Fee</span>
                      <span>₹{deliveryFee}</span>
                    </div>
                  )}
                  <div className={`flex justify-between text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    <span>GST (5%)</span>
                    <span>₹{gst}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-sm text-green-500">
                      <span>Discount</span>
                      <span>-₹{discount}</span>
                    </div>
                  )}
                  <div className={`border-t ${darkMode ? 'border-gray-800' : 'border-gray-200'} pt-2 flex justify-between font-bold text-lg`}>
                    <span>Total</span>
                    <span>₹{total - discount}</span>
                  </div>
                </div>

                <motion.button
                  onClick={onCheckout}
                  className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white py-3 rounded-lg font-medium transition"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Checkout
                </motion.button>
              </motion.div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

// ============ MAIN APP ============
export default function TheBlackSheepBakery() {
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState('pizza');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [isCheckout, setIsCheckout] = useState(false);

  const filteredItems = FOOD_ITEMS.filter(item => item.category === activeCategory);

  const handleAddToCart = (item, quantity) => {
    setCart((prevCart) => {
      const existing = prevCart.find((c) => c.id === item.id);
      if (existing) {
        const updated = { ...existing, quantity: existing.quantity + quantity };
        return updated.quantity <= 0
          ? prevCart.filter((c) => c.id !== item.id)
          : prevCart.map((c) => c.id === item.id ? updated : c);
      }
      return quantity > 0 ? [...prevCart, { ...item, quantity }] : prevCart;
    });
  };

  const handleUpdateCart = (id, quantity) => {
    const item = FOOD_ITEMS.find(i => i.id === id);
    if (item) handleAddToCart(item, quantity);
  };

  return (
    <div className={`${darkMode ? 'bg-gray-950' : 'bg-gray-50'} min-h-screen transition-colors`}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Poppins:wght@400;500;600;700&display=swap');
        
        * {
          font-family: 'Poppins', sans-serif;
        }

        .font-serif {
          font-family: 'Playfair Display', serif;
        }

        ::-webkit-scrollbar {
          width: 8px;
        }

        ::-webkit-scrollbar-track {
          background: ${darkMode ? '#1f2937' : '#f1f1f1'};
        }

        ::-webkit-scrollbar-thumb {
          background: #d97706;
          border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: #b45309;
        }
      `}</style>

      <Navbar
        cart={cart}
        onCartClick={() => setIsCartOpen(true)}
        isLoggedIn={isLoggedIn}
        onLoginClick={() => setIsLoggedIn(true)}
        darkMode={darkMode}
        toggleDarkMode={() => setDarkMode(!darkMode)}
      />

      {!isCheckout ? (
        <>
          <HeroSection
            darkMode={darkMode}
            onExploreClick={() => {
              const menu = document.getElementById('menu');
              menu?.scrollIntoView({ behavior: 'smooth' });
            }}
          />

          <CategoryMenu
            categories={CATEGORIES}
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
            darkMode={darkMode}
          />

          <section id="menu" className="py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                className="mb-12"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
              >
                <h2 className={`font-serif text-4xl font-bold ${darkMode ? 'text-white' : 'text-black'} mb-2 capitalize`}>
                  {activeCategory} Specialties
                </h2>
                <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
                  Handcrafted with premium ingredients
                </p>
              </motion.div>

              <motion.div
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ staggerChildren: 0.1 }}
              >
                {filteredItems.map((item) => (
                  <FoodCard
                    key={item.id}
                    item={item}
                    onAddToCart={handleAddToCart}
                    inCart={cart}
                    darkMode={darkMode}
                    onCustomize={() => {}}
                  />
                ))}
              </motion.div>
            </div>
          </section>

          {/* Info Section */}
          <motion.section
            className={`${darkMode ? 'bg-gray-900' : 'bg-white'} py-16 border-t ${darkMode ? 'border-gray-800' : 'border-gray-200'}`}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
          >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid md:grid-cols-4 gap-8">
                {[
                  { icon: Clock, label: 'Opening Hours', value: '9:00 AM - 11:00 PM' },
                  { icon: Truck, label: 'Free Delivery', value: 'Orders above ₹500' },
                  { icon: Phone, label: 'Contact', value: '+91 98765 43210' },
                  { icon: MapPin, label: 'Location', value: 'Jamshedpur, Jharkhand' },
                ].map((info, i) => (
                  <motion.div
                    key={i}
                    className="text-center"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <info.icon className="w-8 h-8 mx-auto mb-3 text-amber-600" />
                    <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-2`}>
                      {info.label}
                    </div>
                    <div className={`font-medium ${darkMode ? 'text-white' : 'text-black'}`}>
                      {info.value}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.section>
        </>
      ) : (
        // Checkout Page
        <motion.div
          className={`${darkMode ? 'bg-gray-900' : 'bg-white'} min-h-screen mt-16 p-4 sm:p-8`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="max-w-2xl mx-auto">
            <motion.button
              onClick={() => setIsCheckout(false)}
              className={`flex items-center space-x-2 ${darkMode ? 'text-gray-400 hover:text-white' : 'text-black hover:text-gray-600'} mb-8`}
              whileHover={{ x: -4 }}
            >
              <ChevronRight className="w-5 h-5 rotate-180" />
              <span>Back</span>
            </motion.button>

            <h1 className={`font-serif text-3xl font-bold ${darkMode ? 'text-white' : 'text-black'} mb-8`}>
              Checkout
            </h1>

            {/* Delivery Address */}
            <motion.div
              className={`${darkMode ? 'bg-gray-800' : 'bg-gray-50'} p-6 rounded-2xl mb-6`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h2 className={`font-serif text-xl font-bold ${darkMode ? 'text-white' : 'text-black'} mb-4`}>
                Delivery Address
              </h2>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Full Name"
                  className={`w-full px-4 py-3 rounded-lg border ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-amber-500`}
                />
                <input
                  type="text"
                  placeholder="Phone Number"
                  className={`w-full px-4 py-3 rounded-lg border ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-amber-500`}
                />
                <input
                  type="text"
                  placeholder="Full Address"
                  className={`w-full px-4 py-3 rounded-lg border ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-white border-gray-300'} focus:outline-none focus:ring-2 focus:ring-amber-500`}
                />
              </div>
            </motion.div>

            {/* Order Summary */}
            <motion.div
              className={`${darkMode ? 'bg-gray-800' : 'bg-gray-50'} p-6 rounded-2xl mb-6`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <h2 className={`font-serif text-xl font-bold ${darkMode ? 'text-white' : 'text-black'} mb-4`}>
                Order Summary
              </h2>
              <div className="space-y-3 max-h-48 overflow-y-auto mb-4">
                {cart.map((item) => (
                  <div key={item.id} className="flex justify-between">
                    <div>
                      <div className={darkMode ? 'text-white' : 'text-black'}>{item.name}</div>
                      <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                        Qty: {item.quantity}
                      </div>
                    </div>
                    <div className={`font-medium ${darkMode ? 'text-white' : 'text-black'}`}>
                      ₹{item.price * item.quantity}
                    </div>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className={`border-t ${darkMode ? 'border-gray-700' : 'border-gray-300'} pt-4 space-y-2`}>
                <div className={`flex justify-between ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  <span>Subtotal</span>
                  <span>₹{cart.reduce((sum, item) => sum + item.price * item.quantity, 0)}</span>
                </div>
                <div className={`flex justify-between font-bold text-lg ${darkMode ? 'text-white' : 'text-black'}`}>
                  <span>Total</span>
                  <span>₹{Math.round(cart.reduce((sum, item) => sum + item.price * item.quantity, 0) * 1.15)}</span>
                </div>
              </div>
            </motion.div>

            {/* Place Order Button */}
            <motion.button
              onClick={() => {
                alert('Order placed successfully! 🎉');
                setCart([]);
                setIsCheckout(false);
              }}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white py-4 rounded-lg font-bold text-lg transition"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Place Order
            </motion.button>
          </div>
        </motion.div>
      )}

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateCart={handleUpdateCart}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckout(true);
        }}
        darkMode={darkMode}
      />
    </div>
  );
}
