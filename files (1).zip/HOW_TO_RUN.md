# 🚀 How to Run The Black Sheep Bakery Website

## Prerequisites Check

Before starting, make sure you have:
- **Node.js** (version 14 or higher)
- **npm** or **yarn** (comes with Node.js)
- A code editor (VS Code recommended)

### Check if installed:
```bash
node --version
npm --version
```

If not installed, download from [nodejs.org](https://nodejs.org)

---

## Option 1: Create a New Project (Recommended)

### Step 1: Create React App
```bash
npx create-react-app black-sheep-bakery
cd black-sheep-bakery
```

This creates a new folder with all necessary files. **Wait for it to complete** (2-3 minutes).

### Step 2: Install Dependencies

```bash
npm install framer-motion lucide-react
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

This installs:
- `framer-motion` - Animations
- `lucide-react` - Icons
- `tailwindcss` - Styling

### Step 3: Configure Tailwind

Edit `tailwind.config.js`:
```javascript
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

### Step 4: Setup CSS

Replace content of `src/index.css` with:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Poppins:wght@400;500;600;700&display=swap');

body {
  font-family: 'Poppins', sans-serif;
}

.font-serif {
  font-family: 'Playfair Display', serif;
}
```

### Step 5: Add the Component

Create `src/components/BlackSheepBakery.jsx`

Copy the entire code from **BlackSheepBakery.jsx** file and paste it there.

### Step 6: Update App.js

Replace `src/App.js` content with:
```javascript
import BlackSheepBakery from './components/BlackSheepBakery';

function App() {
  return <BlackSheepBakery />;
}

export default App;
```

### Step 7: Run the App

```bash
npm start
```

The browser will open at `http://localhost:3000` 🎉

---

## Option 2: Using Existing React Project

If you already have a React project:

### Step 1: Install Dependencies
```bash
npm install framer-motion lucide-react
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

### Step 2: Configure Tailwind
Update `tailwind.config.js` as shown in Option 1, Step 3

### Step 3: Setup CSS
Update `src/index.css` as shown in Option 1, Step 4

### Step 4: Add Component
Create `src/components/BlackSheepBakery.jsx` with the component code

### Step 5: Import in Your App
In your main App component:
```javascript
import BlackSheepBakery from './components/BlackSheepBakery';

function App() {
  return <BlackSheepBakery />;
}

export default App;
```

### Step 6: Run
```bash
npm start
```

---

## Complete Step-by-Step (Windows/Mac/Linux)

### For Complete Beginners:

#### 1️⃣ Open Terminal/Command Prompt

**Windows**: Press `Win + R`, type `cmd`, press Enter  
**Mac**: Press `Cmd + Space`, type `Terminal`, press Enter  
**Linux**: Open Terminal application

#### 2️⃣ Create the project:
```bash
npx create-react-app black-sheep-bakery
cd black-sheep-bakery
```

**Wait 2-3 minutes for completion**

#### 3️⃣ Install packages:
```bash
npm install framer-motion lucide-react
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

#### 4️⃣ Open in Code Editor

Open VS Code and open the `black-sheep-bakery` folder

#### 5️⃣ Update Files

**File 1: `tailwind.config.js`**
Replace with:
```javascript
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

**File 2: `src/index.css`**
Replace with:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Poppins:wght@400;500;600;700&display=swap');

body {
  font-family: 'Poppins', sans-serif;
}

.font-serif {
  font-family: 'Playfair Display', serif;
}
```

**File 3: `src/App.js`**
Replace with:
```javascript
import BlackSheepBakery from './components/BlackSheepBakery';

function App() {
  return <BlackSheepBakery />;
}

export default App;
```

#### 6️⃣ Create Component File

1. Right-click on `src` folder
2. Create new folder called `components`
3. Inside `components`, create new file `BlackSheepBakery.jsx`
4. Copy entire code from **BlackSheepBakery.jsx** file
5. Paste it into `BlackSheepBakery.jsx`

#### 7️⃣ Run the App

In terminal:
```bash
npm start
```

**Your browser will open automatically!** 🎉

---

## Folder Structure After Setup

```
black-sheep-bakery/
├── node_modules/          (installed packages)
├── public/
│   ├── index.html
│   └── favicon.ico
├── src/
│   ├── components/
│   │   └── BlackSheepBakery.jsx    ✅ Your component
│   ├── App.js                      ✅ Updated
│   ├── App.css
│   ├── index.js
│   └── index.css                   ✅ Updated
├── tailwind.config.js              ✅ Updated
├── postcss.config.js
├── package.json
├── package-lock.json
└── README.md
```

---

## Verify Installation

### Check Node.js:
```bash
node --version
# Should show v14.0.0 or higher
```

### Check npm:
```bash
npm --version
# Should show 6.0.0 or higher
```

### Check dependencies are installed:
```bash
npm list framer-motion
npm list lucide-react
npm list tailwindcss
```

---

## Running the Application

### Development Mode (Default):
```bash
npm start
```
- Opens at `http://localhost:3000`
- Auto-refreshes when you save files
- Shows errors in browser

### Production Build:
```bash
npm run build
```
- Creates optimized version for deployment
- Files go in `build/` folder
- Much smaller file size

### Stop the Server:
Press `Ctrl + C` in terminal

---

## Troubleshooting

### ❌ Issue: "command not found: npm"

**Solution**: Install Node.js from [nodejs.org](https://nodejs.org)

### ❌ Issue: "Cannot find module"

**Solution**: 
```bash
npm install
```
Then restart with:
```bash
npm start
```

### ❌ Issue: Port 3000 already in use

**Solution**:
```bash
# Windows
netstat -ano | findstr :3000
taskkill /PID [PID] /F

# Mac/Linux
lsof -i :3000
kill -9 [PID]
```

Or use different port:
```bash
PORT=3001 npm start
```

### ❌ Issue: Images not loading

**Check**:
1. Internet connection is active (images from Unsplash)
2. Browser console for errors (F12)
3. Try hard refresh (Ctrl+Shift+R)

### ❌ Issue: Styling not working

**Solution**:
1. Check `index.css` has `@tailwind` directives
2. Restart dev server
3. Clear browser cache (Ctrl+Shift+Delete)

### ❌ Issue: "Cannot read property 'map'"

**Solution**: Make sure you copied the entire component code without errors

---

## Test the Website

Once running, test these features:

### 🧪 Testing Checklist:

- [ ] **Page Loads**: Website displays without errors
- [ ] **Images Load**: All food images show correctly
- [ ] **Navigation**: Navbar is visible at top
- [ ] **Hero Section**: Banner image displays
- [ ] **Menu Items**: Food cards show with images
- [ ] **Category Tabs**: Can click bakery, desserts, drinks, combos
- [ ] **Add to Cart**: Click "Add" button on any item
- [ ] **Cart Updates**: Cart count badge increases
- [ ] **Cart Drawer**: Click cart icon, drawer slides open
- [ ] **Remove Item**: Adjust quantity in cart
- [ ] **Gallery**: Scroll to gallery section
- [ ] **Gallery Click**: Click image to expand
- [ ] **Responsive**: Resize browser, check mobile view
- [ ] **Animations**: Hover effects work smoothly

---

## View on Mobile

### Test on your phone:

1. Find your computer's IP:
```bash
# Windows
ipconfig

# Mac/Linux
ifconfig | grep "inet "
```

2. Look for "IPv4 Address" (like 192.168.1.100)

3. On your phone, visit:
```
http://192.168.1.100:3000
```
(Replace IP with your actual IP)

---

## Common Commands

```bash
# Start development server
npm start

# Install new package
npm install package-name

# Build for production
npm run build

# Eject configuration (NOT recommended)
npm run eject

# Clear cache and reinstall
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

---

## Deploy to Internet (Optional)

### Deploy to Vercel (Easiest):

1. Install Vercel CLI:
```bash
npm i -g vercel
```

2. Deploy:
```bash
vercel
```

3. Follow prompts, your site goes live! 🚀

### Deploy to Netlify:

1. Build the app:
```bash
npm run build
```

2. Go to [netlify.com](https://netlify.com)
3. Drag & drop the `build` folder
4. Site goes live! 🎉

---

## Useful VS Code Extensions

Install these for better development:

- **ES7+ React/Redux/React-Native snippets**
- **Tailwind CSS IntelliSense**
- **Thunder Client** (for API testing)
- **Prettier** (code formatter)
- **Live Server** (if using HTML files)

---

## Need Help?

### Check Console for Errors:
1. Press `F12` (DevTools)
2. Go to "Console" tab
3. Look for red error messages

### Read Full Docs:
- [React Documentation](https://react.dev)
- [Tailwind CSS Docs](https://tailwindcss.com)
- [Framer Motion Docs](https://www.framer.com/motion/)

### Check Setup Guide:
See `SETUP_GUIDE.md` for more details

---

## Summary

### Quick Commands:
```bash
# New project
npx create-react-app black-sheep-bakery
cd black-sheep-bakery

# Install dependencies
npm install framer-motion lucide-react
npm install -D tailwindcss postcss autoprefixer

# Initialize Tailwind
npx tailwindcss init -p

# Update config files (as shown above)

# Run development server
npm start
```

**That's it!** 🎉 Your website will be running at `http://localhost:3000`

---

## Next Steps

1. ✅ Run the website
2. 📸 Test all features
3. 🎨 Customize colors and content
4. 🔌 Connect to backend API (see SETUP_GUIDE.md)
5. 🚀 Deploy to production

---

**Happy Coding!** 🐑✨

If you get stuck, check the error message in the terminal or console (F12). Most issues can be solved by:
1. Installing missing packages
2. Restarting dev server (Ctrl+C then `npm start`)
3. Clearing browser cache (Ctrl+Shift+Delete)
